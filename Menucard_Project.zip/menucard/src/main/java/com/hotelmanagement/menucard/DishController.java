package com.hotelmanagement.menucard;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DishController {

	@Autowired
	SessionFactory factory;

	@PostMapping("dish/{tid}")
	public Dish addDish(@RequestBody Dish dish, @PathVariable int tid) {

		Session session = factory.openSession();
		Type type = session.load(Type.class, tid);
		List<Dish> list = type.getDishes();
		Transaction transaction = session.beginTransaction();
		list.add(dish);
		transaction.commit();
		System.out.println("Dish get aaded in database...");

		return dish;
	}

	@GetMapping("dish/{did}")
	public String gelDish(@PathVariable int did) {
		Session session = factory.openSession();
		NativeQuery<Object[]> query = session.createSQLQuery(
				"select dish.did,dish.name,dish.price,type.tid,type.name as tname from type,dish where dish.tid=type.tid and did ="
						+ did);
		List<Object[]> list = query.list();
		Object[] array = list.get(0);
		System.out.println("Dish printed...");
		return Arrays.toString(array);
	}

	@GetMapping("dishes")
	public String getAllDishes() {
		Session session = factory.openSession();
		NativeQuery<Object[]> query = session.createSQLQuery(
				"select dish.did,dish.name,dish.price,type.tid,type.name as tname from type,dish where dish.tid=type.tid");
		List<Object[]> list = query.list();
		StringBuffer stringb = new StringBuffer();
		for (int i = 0; i < list.size(); i++) {
			Object[] array = list.get(i);
			stringb.append(Arrays.toString(array));
		}

		return stringb.toString();
	}

	@PutMapping("dish")
	public String updateProuct(@RequestBody Dish clientdish) {
		Session session = factory.openSession();
		Dish dish = session.load(Dish.class, clientdish.getDid());
		dish.setName(clientdish.getName());
		dish.setPrice(clientdish.getPrice());
		Transaction transaction = session.beginTransaction();
		session.update(dish);
		transaction.commit();
		return "Dish updated...";
	}

	@DeleteMapping("dish/{did}")
	public String deleteDish(@PathVariable int did) {
		Session session = factory.openSession();
		NativeQuery<Object[]> query = session
				.createSQLQuery("select type.tid,type.name from type,dish where dish.tid=type.tid and did =" + did);
		List<Object[]> list = query.list();
		System.out.println(list.size());
		Object[] array = list.get(0);
		int tid = (int) array[0];
		System.out.println(did + " " + tid);
		Type type = session.load(Type.class, tid);
		List<Dish> dishlist = type.getDishes();
		Dish dish = session.load(Dish.class, did);
		Transaction transaction = session.beginTransaction();
		dishlist.remove(dish);
		transaction.commit();

		return "Dish deleted...";
	}

}
