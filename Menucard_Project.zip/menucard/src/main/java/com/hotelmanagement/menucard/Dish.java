package com.hotelmanagement.menucard;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Dish {

	@Id
	private int did;
	private String name;
	private int price;

	public Dish() {
		super();
	}

	public Dish(int did, String name, int price) {
		super();
		this.did = did;
		this.name = name;
		this.price = price;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Dish [did=" + did + ", name=" + name + ", price=" + price + "]";
	}

}
