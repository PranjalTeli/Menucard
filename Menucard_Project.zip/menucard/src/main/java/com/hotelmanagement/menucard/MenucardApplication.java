package com.hotelmanagement.menucard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenucardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenucardApplication.class, args);
	}

}
