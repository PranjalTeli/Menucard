package com.hotelmanagement.menucard;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Type {

	@Id
	int tid;
	String name;
	@OneToMany(targetEntity = Dish.class, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "tid")
	List<Dish> dishes;

	public Type() {
		super();
	}

	public Type(int tid, String name, List<Dish> dishes) {
		super();
		this.tid = tid;
		this.name = name;
		this.dishes = dishes;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Dish> getDishes() {
		return dishes;
	}

	public void setDishes(List<Dish> dishes) {
		this.dishes = dishes;
	}

	@Override
	public String toString() {
		return "Type [tid=" + tid + ", name=" + name + ", dishes=" + dishes + "]";
	}

}
