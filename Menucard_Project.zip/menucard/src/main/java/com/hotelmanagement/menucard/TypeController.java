package com.hotelmanagement.menucard;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TypeController {

	@Autowired
	SessionFactory factory;

	@GetMapping("types")
	public List<Type> getAllType() {

		Session session = factory.openSession();
		Query query = session.createQuery("from Type");
		List<Type> list = query.list();
		System.out.println("Types of food get printed...");
		return list;
	}

	@GetMapping("type/{tid}")
	public Type gettype(@PathVariable int tid) {

		Session session = factory.openSession();
		Type type = session.load(Type.class, tid);
		System.out.println("Type of food get printed...");

		return type;
	}

	@PostMapping("type")
	public Type addType(@RequestBody Type type) {

		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(type);
		transaction.commit();
		System.out.println("Type of food get added in database...");

		return type;

	}

	@PutMapping("type")
	public Type updateType(@RequestBody Type clienttype) {

		Session session = factory.openSession();
		Type type = session.load(Type.class, clienttype.getTid());
		type.setName(clienttype.getName());
		Transaction transaction = session.beginTransaction();
		transaction.commit();
		System.out.println("Type of food get updated in database...");
		
		return type;
	}

	@DeleteMapping("type/{tid}")
	public String deleteType(@PathVariable int tid ) {
		Session session = factory.openSession();
		Type type =session.load(Type.class, tid);
		Transaction transaction = session.beginTransaction();
		session.delete(type);
		transaction.commit();
		
		return "Record deleted...";
	}
	
}
